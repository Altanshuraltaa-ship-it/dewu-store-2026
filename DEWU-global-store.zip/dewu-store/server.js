require("dotenv").config();

const express = require("express");
const session = require("express-session");
const pgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Stripe = require("stripe");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const CURRENCY = (process.env.STORE_CURRENCY || "usd").toLowerCase();
const production = process.env.NODE_ENV === "production";

if (production && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error("SESSION_SECRET must be at least 32 characters in production.");
}
if (!process.env.DATABASE_URL) {
  console.warn("DATABASE_URL is missing. Configure PostgreSQL before starting the store.");
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: false } : undefined
});
const stripe = process.env.STRIPE_SECRET_KEY && process.env.STRIPE_SECRET_KEY.startsWith("sk_")
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : null;

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      connectSrc: ["'self'"],
      formAction: ["'self'", "https://checkout.stripe.com"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: production ? [] : null
    }
  }
}));

// Stripe requires the raw request body to verify webhook signatures.
app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), async (req, res) => {
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) return res.status(503).send("Payments are not configured.");
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook signature verification failed: ${err.message}`);
  }
  try {
    if (event.type === "checkout.session.completed" || event.type === "checkout.session.async_payment_succeeded") {
      const checkout = event.data.object;
      if (checkout.metadata && checkout.metadata.orderId) {
        await pool.query(
          "UPDATE orders SET status = $1, stripe_payment_status = $2, updated_at = NOW() WHERE id = $3",
          ["paid", checkout.payment_status || "paid", checkout.metadata.orderId]
        );
      }
    } else if (event.type === "checkout.session.async_payment_failed") {
      const checkout = event.data.object;
      if (checkout.metadata && checkout.metadata.orderId) {
        await pool.query("UPDATE orders SET status = $1, updated_at = NOW() WHERE id = $2", ["payment_failed", checkout.metadata.orderId]);
      }
    }
    res.json({ received: true });
  } catch (err) {
    console.error("Webhook processing error:", err);
    res.status(500).send("Webhook processing failed.");
  }
});

app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use(session({
  store: new pgSession({
    pool,
    tableName: "user_sessions",
    createTableIfMissing: true
  }),
  name: "dewu.sid",
  secret: process.env.SESSION_SECRET || "local-development-secret-change-before-deploy",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: production,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false }));
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 12, standardHeaders: true, legacyHeaders: false });

function safeUser(user) {
  return { id: user.id, name: user.name, email: user.email, role: user.role };
}
function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Эхлээд нэвтэрнэ үү." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== "admin") {
    return res.status(403).json({ error: "Зөвхөн админ ашиглана." });
  }
  next();
}
function validProduct(body) {
  const name = String(body.name || "").trim();
  const description = String(body.description || "").trim();
  const imageUrl = String(body.imageUrl || "").trim();
  const category = String(body.category || "Sneakers").trim();
  const price = Number(body.price);
  const stock = Number(body.stock);
  if (!name || name.length > 120) return "Барааны нэр 1–120 тэмдэгт байна.";
  if (!Number.isFinite(price) || price < 0.5 || price > 100000) return "Үнэ 0.50–100000 хооронд байх ёстой.";
  if (!Number.isInteger(stock) || stock < 0 || stock > 1000000) return "Үлдэгдэл бүхэл тоо байх ёстой.";
  if (imageUrl && !/^https:\/\/.+/i.test(imageUrl)) return "Зургийн холбоос https://-ээр эхлэх ёстой.";
  return { name, description: description.slice(0, 2000), imageUrl, category: category.slice(0, 50), price, stock };
}

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      email VARCHAR(254) NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role VARCHAR(20) NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS products (
      id BIGSERIAL PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      image_url TEXT NOT NULL DEFAULT '',
      category VARCHAR(50) NOT NULL DEFAULT 'Sneakers',
      price NUMERIC(10,2) NOT NULL CHECK (price >= 0),
      stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
      active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS orders (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
      customer_email VARCHAR(254) NOT NULL,
      items JSONB NOT NULL,
      total NUMERIC(10,2) NOT NULL,
      currency VARCHAR(3) NOT NULL DEFAULT 'usd',
      status VARCHAR(30) NOT NULL DEFAULT 'pending',
      stripe_session_id TEXT UNIQUE,
      stripe_payment_status TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS products_active_idx ON products(active);
    CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders(created_at DESC);
  `);

  const count = await pool.query("SELECT COUNT(*)::int AS n FROM products");
  if (count.rows[0].n === 0) {
    const samples = [
      ["DEWU Runner 01", "Everyday comfort with a clean silhouette.", "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1000&q=85", "Running", 89.00, 18],
      ["DEWU Court Low", "Minimal court sneaker for daily wear.", "https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=1000&q=85", "Lifestyle", 110.00, 12],
      ["DEWU Street High", "A bold high-top built for streetwear.", "https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1000&q=85", "Streetwear", 125.00, 9],
      ["DEWU Classic White", "A versatile staple for any rotation.", "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=1000&q=85", "Lifestyle", 95.00, 24],
      ["DEWU Trail X", "Grip and support for the everyday explorer.", "https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?auto=format&fit=crop&w=1000&q=85", "Outdoor", 139.00, 7],
      ["DEWU Retro 90", "Retro-inspired shape with modern comfort.", "https://images.unsplash.com/photo-1460353581641-37baddies?auto=format&fit=crop&w=1000&q=85", "Retro", 105.00, 5]
    ];
    for (const p of samples.slice(0, 5)) {
      await pool.query(
        "INSERT INTO products(name,description,image_url,category,price,stock) VALUES($1,$2,$3,$4,$5,$6)",
        p
      );
    }
  }

  if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
    const email = process.env.ADMIN_EMAIL.trim().toLowerCase();
    const password = process.env.ADMIN_PASSWORD;
    if (password.length < 12) console.warn("ADMIN_PASSWORD should be at least 12 characters.");
    const hash = await bcrypt.hash(password, 12);
    await pool.query(
      `INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,'admin')
       ON CONFLICT(email) DO UPDATE SET role='admin'`,
      ["DEWU Admin", email, hash]
    );
    console.log(`Admin account ensured for ${email}. Existing password is not changed on conflict.`);
  }
}

app.get("/api/health", async (_req, res) => {
  try { await pool.query("SELECT 1"); res.json({ ok: true, store: "DEWU" }); }
  catch { res.status(503).json({ ok: false }); }
});

app.get("/api/products", async (req, res) => {
  try {
    const q = String(req.query.q || "").trim().slice(0, 100);
    const category = String(req.query.category || "").trim().slice(0, 50);
    const result = await pool.query(
      `SELECT id,name,description,image_url AS "imageUrl",category,price::float,stock
       FROM products WHERE active=TRUE
       AND ($1='' OR name ILIKE '%' || $1 || '%' OR description ILIKE '%' || $1 || '%')
       AND ($2='' OR category=$2) ORDER BY created_at DESC`,
      [q, category]
    );
    res.json({ products: result.rows, currency: CURRENCY });
  } catch (err) { console.error(err); res.status(500).json({ error: "Бараа уншиж чадсангүй." }); }
});

app.get("/api/categories", async (_req, res) => {
  try {
    const r = await pool.query("SELECT DISTINCT category FROM products WHERE active=TRUE ORDER BY category");
    res.json({ categories: r.rows.map(x => x.category) });
  } catch { res.status(500).json({ error: "Ангилал уншиж чадсангүй." }); }
});

app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.post("/api/auth/register", authLimiter, async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2 || name.length > 100) return res.status(400).json({ error: "Нэр 2–100 тэмдэгт байна." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return res.status(400).json({ error: "Имэйл хаягаа шалгана уу." });
    if (password.length < 10 || password.length > 128) return res.status(400).json({ error: "Нууц үг дор хаяж 10 тэмдэгт байх ёстой." });
    const hash = await bcrypt.hash(password, 12);
    const r = await pool.query(
      "INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,email,role",
      [name, email, hash]
    );
    req.session.user = safeUser(r.rows[0]);
    res.status(201).json({ user: req.session.user });
  } catch (err) {
    if (err.code === "23505") return res.status(409).json({ error: "Энэ имэйл бүртгэлтэй байна." });
    console.error(err); res.status(500).json({ error: "Бүртгэл үүсгэж чадсангүй." });
  }
});

app.post("/api/auth/login", authLimiter, async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const r = await pool.query("SELECT * FROM users WHERE email=$1", [email]);
    const user = r.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Имэйл эсвэл нууц үг буруу байна." });
    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: "Нэвтрэхэд алдаа гарлаа." });
      req.session.user = safeUser(user);
      req.session.save(saveErr => {
        if (saveErr) return res.status(500).json({ error: "Session хадгалж чадсангүй." });
        res.json({ user: req.session.user });
      });
    });
  } catch (err) { console.error(err); res.status(500).json({ error: "Нэвтрэхэд алдаа гарлаа." }); }
});

app.post("/api/auth/logout", (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: "Гарахад алдаа гарлаа." });
    res.clearCookie("dewu.sid", { httpOnly: true, secure: production, sameSite: "lax" });
    res.json({ ok: true });
  });
});

app.post("/api/checkout", requireAuth, async (req, res) => {
  if (!stripe) return res.status(503).json({ error: "Төлбөрийн систем тохируулаагүй байна. Stripe түлхүүрээ серверийн environment-д оруулна уу." });
  try {
    const cart = Array.isArray(req.body.items) ? req.body.items : [];
    if (!cart.length || cart.length > 30) return res.status(400).json({ error: "Сагс хоосон эсвэл барааны тоо хэтэрсэн байна." });
    const qtyById = new Map();
    for (const item of cart) {
      const id = Number(item.id), quantity = Number(item.quantity);
      if (!Number.isSafeInteger(id) || id < 1 || !Number.isInteger(quantity) || quantity < 1 || quantity > 10) {
        return res.status(400).json({ error: "Барааны ID эсвэл тоо хэмжээ буруу байна." });
      }
      qtyById.set(id, (qtyById.get(id) || 0) + quantity);
    }
    const ids = [...qtyById.keys()];
    const found = await pool.query(
      "SELECT id,name,price::float,stock,image_url FROM products WHERE active=TRUE AND id=ANY($1::bigint[])",
      [ids]
    );
    if (found.rows.length !== ids.length) return res.status(400).json({ error: "Зарим бараа олдсонгүй." });
    const lines = [];
    let total = 0;
    for (const p of found.rows) {
      const quantity = qtyById.get(Number(p.id));
      if (p.stock < quantity) return res.status(400).json({ error: `${p.name}: үлдэгдэл хүрэлцэхгүй.` });
      total += p.price * quantity;
      lines.push({ id: Number(p.id), name: p.name, price: p.price, quantity, imageUrl: p.image_url });
    }
    const order = await pool.query(
      "INSERT INTO orders(user_id,customer_email,items,total,currency,status) VALUES($1,$2,$3,$4,$5,'pending') RETURNING id",
      [req.session.user.id, req.session.user.email, JSON.stringify(lines), total.toFixed(2), CURRENCY]
    );
    const orderId = order.rows[0].id;
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: req.session.user.email,
      line_items: lines.map(p => ({
        quantity: p.quantity,
        price_data: {
          currency: CURRENCY,
          unit_amount: Math.round(p.price * 100),
          product_data: { name: p.name, images: p.imageUrl && p.imageUrl.startsWith("https://") ? [p.imageUrl] : [] }
        }
      })),
      shipping_address_collection: { allowed_countries: [
        "US","CA","GB","AU","NZ","JP","KR","SG","MY","TH","VN","PH","ID","IN",
        "DE","FR","IT","ES","NL","BE","AT","CH","SE","NO","DK","FI","IE","PT",
        "PL","CZ","GR","HU","RO","BG","HR","SK","SI","EE","LV","LT","LU","MT","CY",
        "AE","SA","QA","KW","BH","OM","IL","TR","MX","BR","CL","CO","PE","ZA"
      ]},
      billing_address_collection: "required",
      success_url: `${BASE_URL}/?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${BASE_URL}/?checkout=cancelled`,
      metadata: { orderId: String(orderId), userId: String(req.session.user.id) }
    });
    await pool.query("UPDATE orders SET stripe_session_id=$1 WHERE id=$2", [session.id, orderId]);
    res.json({ url: session.url });
  } catch (err) {
    console.error("Checkout error:", err);
    res.status(500).json({ error: "Төлбөрийн хуудас үүсгэж чадсангүй." });
  }
});

app.get("/api/orders", requireAuth, async (req, res) => {
  try {
    const r = req.session.user.role === "admin"
      ? await pool.query("SELECT id,customer_email,items,total::float,currency,status,created_at FROM orders ORDER BY created_at DESC LIMIT 200")
      : await pool.query("SELECT id,items,total::float,currency,status,created_at FROM orders WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50", [req.session.user.id]);
    res.json({ orders: r.rows });
  } catch { res.status(500).json({ error: "Захиалга уншиж чадсангүй." }); }
});

// Admin-only product management.
app.get("/api/admin/products", requireAdmin, async (_req, res) => {
  const r = await pool.query("SELECT id,name,description,image_url AS \"imageUrl\",category,price::float,stock,active FROM products ORDER BY created_at DESC");
  res.json({ products: r.rows });
});
app.post("/api/admin/products", requireAdmin, async (req, res) => {
  const p = validProduct(req.body);
  if (typeof p === "string") return res.status(400).json({ error: p });
  try {
    const r = await pool.query(
      "INSERT INTO products(name,description,image_url,category,price,stock) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,name,description,image_url AS \"imageUrl\",category,price::float,stock,active",
      [p.name,p.description,p.imageUrl,p.category,p.price,p.stock]
    );
    res.status(201).json({ product: r.rows[0] });
  } catch (err) { console.error(err); res.status(500).json({ error: "Бараа нэмэж чадсангүй." }); }
});
app.put("/api/admin/products/:id", requireAdmin, async (req, res) => {
  const id = Number(req.params.id), p = validProduct(req.body);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: "ID буруу байна." });
  if (typeof p === "string") return res.status(400).json({ error: p });
  try {
    const r = await pool.query(
      "UPDATE products SET name=$1,description=$2,image_url=$3,category=$4,price=$5,stock=$6 WHERE id=$7 RETURNING id,name,description,image_url AS \"imageUrl\",category,price::float,stock,active",
      [p.name,p.description,p.imageUrl,p.category,p.price,p.stock,id]
    );
    if (!r.rowCount) return res.status(404).json({ error: "Бараа олдсонгүй." });
    res.json({ product: r.rows[0] });
  } catch (err) { console.error(err); res.status(500).json({ error: "Бараа шинэчилж чадсангүй." }); }
});
app.delete("/api/admin/products/:id", requireAdmin, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) return res.status(400).json({ error: "ID буруу байна." });
  const r = await pool.query("UPDATE products SET active=FALSE WHERE id=$1 RETURNING id", [id]);
  if (!r.rowCount) return res.status(404).json({ error: "Бараа олдсонгүй." });
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"] }));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

initDb().then(() => {
  app.listen(PORT, () => console.log(`DEWU running at ${BASE_URL}`));
}).catch(err => {
  console.error("Startup failed. Check DATABASE_URL and database permissions.", err);
  process.exit(1);
});

process.on("SIGTERM", async () => {
  await pool.end();
  process.exit(0);
});
